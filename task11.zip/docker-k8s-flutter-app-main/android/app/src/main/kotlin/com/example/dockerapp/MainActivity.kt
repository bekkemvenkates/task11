package com.example.dockerapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
